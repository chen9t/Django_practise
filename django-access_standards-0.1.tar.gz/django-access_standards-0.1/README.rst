access_standards:迁入、迁出标准
================================

设置：
---------
1. 在setting.py中的INSTALLED_APPS设置中增加access_standards应用：

	INSTALLED_APPS = (
		...
      'access_standards',
      	) 

2. 在mysite/urls.py中增加：

	url(r'^access_standards/$', include('access_standards.urls')),

3. 运行 'python manage.py syncdb' 在数据库中同步表模型；

4. 在数据库中相应表中插入数据（access_standard.csv）:
	
	在Navicat中打开表“access_standard”，然后导入access_standard.csv模型（共351条数据）。	
