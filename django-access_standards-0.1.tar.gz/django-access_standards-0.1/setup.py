import os
from setuptools import setup


README = open(os.path.join(os.path.dirname(__file__), 'README.rst')).read()

setup(
    name='django-access_standards',
    version='0.1',
    packages=['access_standards'],
	 include_package_data=True,
    )
